import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _330a13cc = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _6361904d = () => interopDefault(import('..\\pages\\_lang\\index.vue' /* webpackChunkName: "pages/_lang/index" */))
const _78f04926 = () => interopDefault(import('..\\pages\\_lang\\aboutus.vue' /* webpackChunkName: "pages/_lang/aboutus" */))
const _a7eba456 = () => interopDefault(import('..\\pages\\_lang\\addrTrack.vue' /* webpackChunkName: "pages/_lang/addrTrack" */))
const _06b89f80 = () => interopDefault(import('..\\pages\\_lang\\bch\\index.vue' /* webpackChunkName: "pages/_lang/bch/index" */))
const _a6423814 = () => interopDefault(import('..\\pages\\_lang\\btc\\index.vue' /* webpackChunkName: "pages/_lang/btc/index" */))
const _d7c5808a = () => interopDefault(import('..\\pages\\_lang\\dash\\index.vue' /* webpackChunkName: "pages/_lang/dash/index" */))
const _527840d3 = () => interopDefault(import('..\\pages\\_lang\\etc\\index.vue' /* webpackChunkName: "pages/_lang/etc/index" */))
const _78f07bae = () => interopDefault(import('..\\pages\\_lang\\eth\\index.vue' /* webpackChunkName: "pages/_lang/eth/index" */))
const _7f88c42c = () => interopDefault(import('..\\pages\\_lang\\ltc\\index.vue' /* webpackChunkName: "pages/_lang/ltc/index" */))
const _96e15a86 = () => interopDefault(import('..\\pages\\_lang\\search.vue' /* webpackChunkName: "pages/_lang/search" */))
const _201f49b9 = () => interopDefault(import('..\\pages\\_lang\\transationTrack.vue' /* webpackChunkName: "pages/_lang/transationTrack" */))
const _88b70bf0 = () => interopDefault(import('..\\pages\\_lang\\bch\\blocks.vue' /* webpackChunkName: "pages/_lang/bch/blocks" */))
const _d895edf6 = () => interopDefault(import('..\\pages\\_lang\\bch\\pending.vue' /* webpackChunkName: "pages/_lang/bch/pending" */))
const _3149acde = () => interopDefault(import('..\\pages\\_lang\\bch\\rich.vue' /* webpackChunkName: "pages/_lang/bch/rich" */))
const _06a53bcc = () => interopDefault(import('..\\pages\\_lang\\bch\\transaction.vue' /* webpackChunkName: "pages/_lang/bch/transaction" */))
const _12cfbd12 = () => interopDefault(import('..\\pages\\_lang\\btc\\blocks.vue' /* webpackChunkName: "pages/_lang/btc/blocks" */))
const _21f2273b = () => interopDefault(import('..\\pages\\_lang\\btc\\pending.vue' /* webpackChunkName: "pages/_lang/btc/pending" */))
const _68c3ab30 = () => interopDefault(import('..\\pages\\_lang\\btc\\rich.vue' /* webpackChunkName: "pages/_lang/btc/rich" */))
const _4fc761fc = () => interopDefault(import('..\\pages\\_lang\\btc\\transaction.vue' /* webpackChunkName: "pages/_lang/btc/transaction" */))
const _135cd9ed = () => interopDefault(import('..\\pages\\_lang\\dash\\blocks.vue' /* webpackChunkName: "pages/_lang/dash/blocks" */))
const _3308a5c0 = () => interopDefault(import('..\\pages\\_lang\\dash\\pending.vue' /* webpackChunkName: "pages/_lang/dash/pending" */))
const _4ef2c203 = () => interopDefault(import('..\\pages\\_lang\\dash\\rich.vue' /* webpackChunkName: "pages/_lang/dash/rich" */))
const _65160307 = () => interopDefault(import('..\\pages\\_lang\\dash\\transaction.vue' /* webpackChunkName: "pages/_lang/dash/transaction" */))
const _2061fbd5 = () => interopDefault(import('..\\pages\\_lang\\etc\\blocks.vue' /* webpackChunkName: "pages/_lang/etc/blocks" */))
const _72b07e50 = () => interopDefault(import('..\\pages\\_lang\\etc\\pending.vue' /* webpackChunkName: "pages/_lang/etc/pending" */))
const _d1b1842a = () => interopDefault(import('..\\pages\\_lang\\etc\\rich.vue' /* webpackChunkName: "pages/_lang/etc/rich" */))
const _e1fc5bc2 = () => interopDefault(import('..\\pages\\_lang\\etc\\transaction.vue' /* webpackChunkName: "pages/_lang/etc/transaction" */))
const _6e1dc74c = () => interopDefault(import('..\\pages\\_lang\\eth\\blocks.vue' /* webpackChunkName: "pages/_lang/eth/blocks" */))
const _2ffcb0f3 = () => interopDefault(import('..\\pages\\_lang\\eth\\pending.vue' /* webpackChunkName: "pages/_lang/eth/pending" */))
const _7f9ebbb0 = () => interopDefault(import('..\\pages\\_lang\\eth\\rich.vue' /* webpackChunkName: "pages/_lang/eth/rich" */))
const _fb62ab24 = () => interopDefault(import('..\\pages\\_lang\\eth\\tokens.vue' /* webpackChunkName: "pages/_lang/eth/tokens" */))
const _65db3cba = () => interopDefault(import('..\\pages\\_lang\\eth\\transaction.vue' /* webpackChunkName: "pages/_lang/eth/transaction" */))
const _d53c38c8 = () => interopDefault(import('..\\pages\\_lang\\ltc\\blocks.vue' /* webpackChunkName: "pages/_lang/ltc/blocks" */))
const _1cb65c1e = () => interopDefault(import('..\\pages\\_lang\\ltc\\pending.vue' /* webpackChunkName: "pages/_lang/ltc/pending" */))
const _1cbc6b72 = () => interopDefault(import('..\\pages\\_lang\\ltc\\rich.vue' /* webpackChunkName: "pages/_lang/ltc/rich" */))
const _3722a290 = () => interopDefault(import('..\\pages\\_lang\\ltc\\transaction.vue' /* webpackChunkName: "pages/_lang/ltc/transaction" */))
const _55dba7c8 = () => interopDefault(import('..\\pages\\_lang\\bch\\address\\_id.vue' /* webpackChunkName: "pages/_lang/bch/address/_id" */))
const _f7112462 = () => interopDefault(import('..\\pages\\_lang\\bch\\block\\_id.vue' /* webpackChunkName: "pages/_lang/bch/block/_id" */))
const _43313224 = () => interopDefault(import('..\\pages\\_lang\\bch\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/bch/tx/_id" */))
const _9972095c = () => interopDefault(import('..\\pages\\_lang\\btc\\address\\_id.vue' /* webpackChunkName: "pages/_lang/btc/address/_id" */))
const _0253c84e = () => interopDefault(import('..\\pages\\_lang\\btc\\block\\_id.vue' /* webpackChunkName: "pages/_lang/btc/block/_id" */))
const _5d235f4c = () => interopDefault(import('..\\pages\\_lang\\btc\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/btc/tx/_id" */))
const _74f87026 = () => interopDefault(import('..\\pages\\_lang\\dash\\address\\_id.vue' /* webpackChunkName: "pages/_lang/dash/address/_id" */))
const _f0f95998 = () => interopDefault(import('..\\pages\\_lang\\dash\\block\\_id.vue' /* webpackChunkName: "pages/_lang/dash/block/_id" */))
const _3af66242 = () => interopDefault(import('..\\pages\\_lang\\dash\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/dash/tx/_id" */))
const _4ddc4856 = () => interopDefault(import('..\\pages\\_lang\\etc\\address\\_id.vue' /* webpackChunkName: "pages/_lang/etc/address/_id" */))
const _67d5411c = () => interopDefault(import('..\\pages\\_lang\\etc\\block\\_id.vue' /* webpackChunkName: "pages/_lang/etc/block/_id" */))
const _0654b5a0 = () => interopDefault(import('..\\pages\\_lang\\etc\\token\\_id.vue' /* webpackChunkName: "pages/_lang/etc/token/_id" */))
const _7623e9f7 = () => interopDefault(import('..\\pages\\_lang\\etc\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/etc/tx/_id" */))
const _2e4f2686 = () => interopDefault(import('..\\pages\\_lang\\etc\\uncle\\_id.vue' /* webpackChunkName: "pages/_lang/etc/uncle/_id" */))
const _453476cc = () => interopDefault(import('..\\pages\\_lang\\eth\\address\\_id.vue' /* webpackChunkName: "pages/_lang/eth/address/_id" */))
const _09b2d1be = () => interopDefault(import('..\\pages\\_lang\\eth\\block\\_id.vue' /* webpackChunkName: "pages/_lang/eth/block/_id" */))
const _dfb20996 = () => interopDefault(import('..\\pages\\_lang\\eth\\token\\_id.vue' /* webpackChunkName: "pages/_lang/eth/token/_id" */))
const _410e4bdc = () => interopDefault(import('..\\pages\\_lang\\eth\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/eth/tx/_id" */))
const _7cbf06ea = () => interopDefault(import('..\\pages\\_lang\\eth\\uncle\\_id.vue' /* webpackChunkName: "pages/_lang/eth/uncle/_id" */))
const _3140925c = () => interopDefault(import('..\\pages\\_lang\\ltc\\address\\_id.vue' /* webpackChunkName: "pages/_lang/ltc/address/_id" */))
const _077ded63 = () => interopDefault(import('..\\pages\\_lang\\ltc\\block\\_id.vue' /* webpackChunkName: "pages/_lang/ltc/block/_id" */))
const _bdbe09e0 = () => interopDefault(import('..\\pages\\_lang\\ltc\\tx\\_id.vue' /* webpackChunkName: "pages/_lang/ltc/tx/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _330a13cc,
    name: "index"
  }, {
    path: "/:lang",
    component: _6361904d,
    name: "lang"
  }, {
    path: "/:lang/aboutus",
    component: _78f04926,
    name: "lang-aboutus"
  }, {
    path: "/:lang/addrTrack",
    component: _a7eba456,
    name: "lang-addrTrack"
  }, {
    path: "/:lang/bch",
    component: _06b89f80,
    name: "lang-bch"
  }, {
    path: "/:lang/btc",
    component: _a6423814,
    name: "lang-btc"
  }, {
    path: "/:lang/dash",
    component: _d7c5808a,
    name: "lang-dash"
  }, {
    path: "/:lang/etc",
    component: _527840d3,
    name: "lang-etc"
  }, {
    path: "/:lang/eth",
    component: _78f07bae,
    name: "lang-eth"
  }, {
    path: "/:lang/ltc",
    component: _7f88c42c,
    name: "lang-ltc"
  }, {
    path: "/:lang/search",
    component: _96e15a86,
    name: "lang-search"
  }, {
    path: "/:lang/transationTrack",
    component: _201f49b9,
    name: "lang-transationTrack"
  }, {
    path: "/:lang/bch/blocks",
    component: _88b70bf0,
    name: "lang-bch-blocks"
  }, {
    path: "/:lang/bch/pending",
    component: _d895edf6,
    name: "lang-bch-pending"
  }, {
    path: "/:lang/bch/rich",
    component: _3149acde,
    name: "lang-bch-rich"
  }, {
    path: "/:lang/bch/transaction",
    component: _06a53bcc,
    name: "lang-bch-transaction"
  }, {
    path: "/:lang/btc/blocks",
    component: _12cfbd12,
    name: "lang-btc-blocks"
  }, {
    path: "/:lang/btc/pending",
    component: _21f2273b,
    name: "lang-btc-pending"
  }, {
    path: "/:lang/btc/rich",
    component: _68c3ab30,
    name: "lang-btc-rich"
  }, {
    path: "/:lang/btc/transaction",
    component: _4fc761fc,
    name: "lang-btc-transaction"
  }, {
    path: "/:lang/dash/blocks",
    component: _135cd9ed,
    name: "lang-dash-blocks"
  }, {
    path: "/:lang/dash/pending",
    component: _3308a5c0,
    name: "lang-dash-pending"
  }, {
    path: "/:lang/dash/rich",
    component: _4ef2c203,
    name: "lang-dash-rich"
  }, {
    path: "/:lang/dash/transaction",
    component: _65160307,
    name: "lang-dash-transaction"
  }, {
    path: "/:lang/etc/blocks",
    component: _2061fbd5,
    name: "lang-etc-blocks"
  }, {
    path: "/:lang/etc/pending",
    component: _72b07e50,
    name: "lang-etc-pending"
  }, {
    path: "/:lang/etc/rich",
    component: _d1b1842a,
    name: "lang-etc-rich"
  }, {
    path: "/:lang/etc/transaction",
    component: _e1fc5bc2,
    name: "lang-etc-transaction"
  }, {
    path: "/:lang/eth/blocks",
    component: _6e1dc74c,
    name: "lang-eth-blocks"
  }, {
    path: "/:lang/eth/pending",
    component: _2ffcb0f3,
    name: "lang-eth-pending"
  }, {
    path: "/:lang/eth/rich",
    component: _7f9ebbb0,
    name: "lang-eth-rich"
  }, {
    path: "/:lang/eth/tokens",
    component: _fb62ab24,
    name: "lang-eth-tokens"
  }, {
    path: "/:lang/eth/transaction",
    component: _65db3cba,
    name: "lang-eth-transaction"
  }, {
    path: "/:lang/ltc/blocks",
    component: _d53c38c8,
    name: "lang-ltc-blocks"
  }, {
    path: "/:lang/ltc/pending",
    component: _1cb65c1e,
    name: "lang-ltc-pending"
  }, {
    path: "/:lang/ltc/rich",
    component: _1cbc6b72,
    name: "lang-ltc-rich"
  }, {
    path: "/:lang/ltc/transaction",
    component: _3722a290,
    name: "lang-ltc-transaction"
  }, {
    path: "/:lang/bch/address/:id?",
    component: _55dba7c8,
    name: "lang-bch-address-id"
  }, {
    path: "/:lang/bch/block/:id?",
    component: _f7112462,
    name: "lang-bch-block-id"
  }, {
    path: "/:lang/bch/tx/:id?",
    component: _43313224,
    name: "lang-bch-tx-id"
  }, {
    path: "/:lang/btc/address/:id?",
    component: _9972095c,
    name: "lang-btc-address-id"
  }, {
    path: "/:lang/btc/block/:id?",
    component: _0253c84e,
    name: "lang-btc-block-id"
  }, {
    path: "/:lang/btc/tx/:id?",
    component: _5d235f4c,
    name: "lang-btc-tx-id"
  }, {
    path: "/:lang/dash/address/:id?",
    component: _74f87026,
    name: "lang-dash-address-id"
  }, {
    path: "/:lang/dash/block/:id?",
    component: _f0f95998,
    name: "lang-dash-block-id"
  }, {
    path: "/:lang/dash/tx/:id?",
    component: _3af66242,
    name: "lang-dash-tx-id"
  }, {
    path: "/:lang/etc/address/:id?",
    component: _4ddc4856,
    name: "lang-etc-address-id"
  }, {
    path: "/:lang/etc/block/:id?",
    component: _67d5411c,
    name: "lang-etc-block-id"
  }, {
    path: "/:lang/etc/token/:id?",
    component: _0654b5a0,
    name: "lang-etc-token-id"
  }, {
    path: "/:lang/etc/tx/:id?",
    component: _7623e9f7,
    name: "lang-etc-tx-id"
  }, {
    path: "/:lang/etc/uncle/:id?",
    component: _2e4f2686,
    name: "lang-etc-uncle-id"
  }, {
    path: "/:lang/eth/address/:id?",
    component: _453476cc,
    name: "lang-eth-address-id"
  }, {
    path: "/:lang/eth/block/:id?",
    component: _09b2d1be,
    name: "lang-eth-block-id"
  }, {
    path: "/:lang/eth/token/:id?",
    component: _dfb20996,
    name: "lang-eth-token-id"
  }, {
    path: "/:lang/eth/tx/:id?",
    component: _410e4bdc,
    name: "lang-eth-tx-id"
  }, {
    path: "/:lang/eth/uncle/:id?",
    component: _7cbf06ea,
    name: "lang-eth-uncle-id"
  }, {
    path: "/:lang/ltc/address/:id?",
    component: _3140925c,
    name: "lang-ltc-address-id"
  }, {
    path: "/:lang/ltc/block/:id?",
    component: _077ded63,
    name: "lang-ltc-block-id"
  }, {
    path: "/:lang/ltc/tx/:id?",
    component: _bdbe09e0,
    name: "lang-ltc-tx-id"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
