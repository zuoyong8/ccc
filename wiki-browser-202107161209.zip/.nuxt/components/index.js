import { wrapFunctional } from './utils'

export { default as Banner } from '../..\\components\\Banner.vue'
export { default as BasicChart } from '../..\\components\\BasicChart.vue'
export { default as BasicInfo } from '../..\\components\\BasicInfo.vue'
export { default as BasicItem } from '../..\\components\\BasicItem.vue'
export { default as Bread } from '../..\\components\\Bread.vue'
export { default as Copy } from '../..\\components\\Copy.vue'
export { default as LangSelect } from '../..\\components\\LangSelect.vue'
export { default as LastTime } from '../..\\components\\LastTime.vue'
export { default as Loading } from '../..\\components\\Loading.vue'
export { default as PageTop } from '../..\\components\\PageTop.vue'
export { default as Pagination } from '../..\\components\\Pagination.vue'
export { default as PendTop } from '../..\\components\\PendTop.vue'
export { default as QrCode } from '../..\\components\\QrCode.vue'
export { default as Search } from '../..\\components\\Search.vue'
export { default as SelectImg } from '../..\\components\\SelectImg.vue'
export { default as SvgIcon } from '../..\\components\\SvgIcon.vue'
export { default as THeader } from '../..\\components\\THeader.vue'
export { default as Tip } from '../..\\components\\Tip.vue'
export { default as TxNoData } from '../..\\components\\TxNoData.vue'
export { default as BtcTraItemAddr } from '../..\\components\\btc\\TraItemAddr.vue'
export { default as BtcTraItemBlock } from '../..\\components\\btc\\TraItemBlock.vue'
export { default as BtcTraItemHash } from '../..\\components\\btc\\TraItemHash.vue'
export { default as EthAddrHolder } from '../..\\components\\eth\\AddrHolder.vue'
export { default as EthErcTx } from '../..\\components\\eth\\ErcTx.vue'
export { default as EthFromTag } from '../..\\components\\eth\\FromTag.vue'
export { default as EthStatusIcon } from '../..\\components\\eth\\StatusIcon.vue'
export { default as EthTokenHolderList } from '../..\\components\\eth\\TokenHolderList.vue'
export { default as EthTokenTransferList } from '../..\\components\\eth\\TokenTransferList.vue'
export { default as EthToTag } from '../..\\components\\eth\\ToTag.vue'
export { default as EthTransactionList } from '../..\\components\\eth\\TransactionList.vue'
export { default as EthTransferList } from '../..\\components\\eth\\TransferList.vue'
export { default as EthTxTip } from '../..\\components\\eth\\TxTip.vue'
export { default as EthTxTokens } from '../..\\components\\eth\\TxTokens.vue'
export { default as EthTxTransfer } from '../..\\components\\eth\\TxTransfer.vue'
export { default as EthUncleList } from '../..\\components\\eth\\UncleList.vue'
export { default as EthValColor } from '../..\\components\\eth\\ValColor.vue'
export { default as LayoutMenu } from '../..\\components\\layout\\Menu.vue'
export { default as LayoutNav } from '../..\\components\\layout\\Nav.vue'
export { default as LayoutPageFooter } from '../..\\components\\layout\\PageFooter.vue'

export const LazyBanner = import('../..\\components\\Banner.vue' /* webpackChunkName: "components/banner" */).then(c => wrapFunctional(c.default || c))
export const LazyBasicChart = import('../..\\components\\BasicChart.vue' /* webpackChunkName: "components/basic-chart" */).then(c => wrapFunctional(c.default || c))
export const LazyBasicInfo = import('../..\\components\\BasicInfo.vue' /* webpackChunkName: "components/basic-info" */).then(c => wrapFunctional(c.default || c))
export const LazyBasicItem = import('../..\\components\\BasicItem.vue' /* webpackChunkName: "components/basic-item" */).then(c => wrapFunctional(c.default || c))
export const LazyBread = import('../..\\components\\Bread.vue' /* webpackChunkName: "components/bread" */).then(c => wrapFunctional(c.default || c))
export const LazyCopy = import('../..\\components\\Copy.vue' /* webpackChunkName: "components/copy" */).then(c => wrapFunctional(c.default || c))
export const LazyLangSelect = import('../..\\components\\LangSelect.vue' /* webpackChunkName: "components/lang-select" */).then(c => wrapFunctional(c.default || c))
export const LazyLastTime = import('../..\\components\\LastTime.vue' /* webpackChunkName: "components/last-time" */).then(c => wrapFunctional(c.default || c))
export const LazyLoading = import('../..\\components\\Loading.vue' /* webpackChunkName: "components/loading" */).then(c => wrapFunctional(c.default || c))
export const LazyPageTop = import('../..\\components\\PageTop.vue' /* webpackChunkName: "components/page-top" */).then(c => wrapFunctional(c.default || c))
export const LazyPagination = import('../..\\components\\Pagination.vue' /* webpackChunkName: "components/pagination" */).then(c => wrapFunctional(c.default || c))
export const LazyPendTop = import('../..\\components\\PendTop.vue' /* webpackChunkName: "components/pend-top" */).then(c => wrapFunctional(c.default || c))
export const LazyQrCode = import('../..\\components\\QrCode.vue' /* webpackChunkName: "components/qr-code" */).then(c => wrapFunctional(c.default || c))
export const LazySearch = import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c))
export const LazySelectImg = import('../..\\components\\SelectImg.vue' /* webpackChunkName: "components/select-img" */).then(c => wrapFunctional(c.default || c))
export const LazySvgIcon = import('../..\\components\\SvgIcon.vue' /* webpackChunkName: "components/svg-icon" */).then(c => wrapFunctional(c.default || c))
export const LazyTHeader = import('../..\\components\\THeader.vue' /* webpackChunkName: "components/t-header" */).then(c => wrapFunctional(c.default || c))
export const LazyTip = import('../..\\components\\Tip.vue' /* webpackChunkName: "components/tip" */).then(c => wrapFunctional(c.default || c))
export const LazyTxNoData = import('../..\\components\\TxNoData.vue' /* webpackChunkName: "components/tx-no-data" */).then(c => wrapFunctional(c.default || c))
export const LazyBtcTraItemAddr = import('../..\\components\\btc\\TraItemAddr.vue' /* webpackChunkName: "components/btc-tra-item-addr" */).then(c => wrapFunctional(c.default || c))
export const LazyBtcTraItemBlock = import('../..\\components\\btc\\TraItemBlock.vue' /* webpackChunkName: "components/btc-tra-item-block" */).then(c => wrapFunctional(c.default || c))
export const LazyBtcTraItemHash = import('../..\\components\\btc\\TraItemHash.vue' /* webpackChunkName: "components/btc-tra-item-hash" */).then(c => wrapFunctional(c.default || c))
export const LazyEthAddrHolder = import('../..\\components\\eth\\AddrHolder.vue' /* webpackChunkName: "components/eth-addr-holder" */).then(c => wrapFunctional(c.default || c))
export const LazyEthErcTx = import('../..\\components\\eth\\ErcTx.vue' /* webpackChunkName: "components/eth-erc-tx" */).then(c => wrapFunctional(c.default || c))
export const LazyEthFromTag = import('../..\\components\\eth\\FromTag.vue' /* webpackChunkName: "components/eth-from-tag" */).then(c => wrapFunctional(c.default || c))
export const LazyEthStatusIcon = import('../..\\components\\eth\\StatusIcon.vue' /* webpackChunkName: "components/eth-status-icon" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTokenHolderList = import('../..\\components\\eth\\TokenHolderList.vue' /* webpackChunkName: "components/eth-token-holder-list" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTokenTransferList = import('../..\\components\\eth\\TokenTransferList.vue' /* webpackChunkName: "components/eth-token-transfer-list" */).then(c => wrapFunctional(c.default || c))
export const LazyEthToTag = import('../..\\components\\eth\\ToTag.vue' /* webpackChunkName: "components/eth-to-tag" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTransactionList = import('../..\\components\\eth\\TransactionList.vue' /* webpackChunkName: "components/eth-transaction-list" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTransferList = import('../..\\components\\eth\\TransferList.vue' /* webpackChunkName: "components/eth-transfer-list" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTxTip = import('../..\\components\\eth\\TxTip.vue' /* webpackChunkName: "components/eth-tx-tip" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTxTokens = import('../..\\components\\eth\\TxTokens.vue' /* webpackChunkName: "components/eth-tx-tokens" */).then(c => wrapFunctional(c.default || c))
export const LazyEthTxTransfer = import('../..\\components\\eth\\TxTransfer.vue' /* webpackChunkName: "components/eth-tx-transfer" */).then(c => wrapFunctional(c.default || c))
export const LazyEthUncleList = import('../..\\components\\eth\\UncleList.vue' /* webpackChunkName: "components/eth-uncle-list" */).then(c => wrapFunctional(c.default || c))
export const LazyEthValColor = import('../..\\components\\eth\\ValColor.vue' /* webpackChunkName: "components/eth-val-color" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutMenu = import('../..\\components\\layout\\Menu.vue' /* webpackChunkName: "components/layout-menu" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutNav = import('../..\\components\\layout\\Nav.vue' /* webpackChunkName: "components/layout-nav" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutPageFooter = import('../..\\components\\layout\\PageFooter.vue' /* webpackChunkName: "components/layout-page-footer" */).then(c => wrapFunctional(c.default || c))
