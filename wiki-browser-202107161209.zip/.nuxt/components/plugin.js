import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Banner: () => import('../..\\components\\Banner.vue' /* webpackChunkName: "components/banner" */).then(c => wrapFunctional(c.default || c)),
  BasicChart: () => import('../..\\components\\BasicChart.vue' /* webpackChunkName: "components/basic-chart" */).then(c => wrapFunctional(c.default || c)),
  BasicInfo: () => import('../..\\components\\BasicInfo.vue' /* webpackChunkName: "components/basic-info" */).then(c => wrapFunctional(c.default || c)),
  BasicItem: () => import('../..\\components\\BasicItem.vue' /* webpackChunkName: "components/basic-item" */).then(c => wrapFunctional(c.default || c)),
  Bread: () => import('../..\\components\\Bread.vue' /* webpackChunkName: "components/bread" */).then(c => wrapFunctional(c.default || c)),
  Copy: () => import('../..\\components\\Copy.vue' /* webpackChunkName: "components/copy" */).then(c => wrapFunctional(c.default || c)),
  LangSelect: () => import('../..\\components\\LangSelect.vue' /* webpackChunkName: "components/lang-select" */).then(c => wrapFunctional(c.default || c)),
  LastTime: () => import('../..\\components\\LastTime.vue' /* webpackChunkName: "components/last-time" */).then(c => wrapFunctional(c.default || c)),
  Loading: () => import('../..\\components\\Loading.vue' /* webpackChunkName: "components/loading" */).then(c => wrapFunctional(c.default || c)),
  PageTop: () => import('../..\\components\\PageTop.vue' /* webpackChunkName: "components/page-top" */).then(c => wrapFunctional(c.default || c)),
  Pagination: () => import('../..\\components\\Pagination.vue' /* webpackChunkName: "components/pagination" */).then(c => wrapFunctional(c.default || c)),
  PendTop: () => import('../..\\components\\PendTop.vue' /* webpackChunkName: "components/pend-top" */).then(c => wrapFunctional(c.default || c)),
  QrCode: () => import('../..\\components\\QrCode.vue' /* webpackChunkName: "components/qr-code" */).then(c => wrapFunctional(c.default || c)),
  Search: () => import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c)),
  SelectImg: () => import('../..\\components\\SelectImg.vue' /* webpackChunkName: "components/select-img" */).then(c => wrapFunctional(c.default || c)),
  SvgIcon: () => import('../..\\components\\SvgIcon.vue' /* webpackChunkName: "components/svg-icon" */).then(c => wrapFunctional(c.default || c)),
  THeader: () => import('../..\\components\\THeader.vue' /* webpackChunkName: "components/t-header" */).then(c => wrapFunctional(c.default || c)),
  Tip: () => import('../..\\components\\Tip.vue' /* webpackChunkName: "components/tip" */).then(c => wrapFunctional(c.default || c)),
  TxNoData: () => import('../..\\components\\TxNoData.vue' /* webpackChunkName: "components/tx-no-data" */).then(c => wrapFunctional(c.default || c)),
  BtcTraItemAddr: () => import('../..\\components\\btc\\TraItemAddr.vue' /* webpackChunkName: "components/btc-tra-item-addr" */).then(c => wrapFunctional(c.default || c)),
  BtcTraItemBlock: () => import('../..\\components\\btc\\TraItemBlock.vue' /* webpackChunkName: "components/btc-tra-item-block" */).then(c => wrapFunctional(c.default || c)),
  BtcTraItemHash: () => import('../..\\components\\btc\\TraItemHash.vue' /* webpackChunkName: "components/btc-tra-item-hash" */).then(c => wrapFunctional(c.default || c)),
  EthAddrHolder: () => import('../..\\components\\eth\\AddrHolder.vue' /* webpackChunkName: "components/eth-addr-holder" */).then(c => wrapFunctional(c.default || c)),
  EthErcTx: () => import('../..\\components\\eth\\ErcTx.vue' /* webpackChunkName: "components/eth-erc-tx" */).then(c => wrapFunctional(c.default || c)),
  EthFromTag: () => import('../..\\components\\eth\\FromTag.vue' /* webpackChunkName: "components/eth-from-tag" */).then(c => wrapFunctional(c.default || c)),
  EthStatusIcon: () => import('../..\\components\\eth\\StatusIcon.vue' /* webpackChunkName: "components/eth-status-icon" */).then(c => wrapFunctional(c.default || c)),
  EthTokenHolderList: () => import('../..\\components\\eth\\TokenHolderList.vue' /* webpackChunkName: "components/eth-token-holder-list" */).then(c => wrapFunctional(c.default || c)),
  EthTokenTransferList: () => import('../..\\components\\eth\\TokenTransferList.vue' /* webpackChunkName: "components/eth-token-transfer-list" */).then(c => wrapFunctional(c.default || c)),
  EthToTag: () => import('../..\\components\\eth\\ToTag.vue' /* webpackChunkName: "components/eth-to-tag" */).then(c => wrapFunctional(c.default || c)),
  EthTransactionList: () => import('../..\\components\\eth\\TransactionList.vue' /* webpackChunkName: "components/eth-transaction-list" */).then(c => wrapFunctional(c.default || c)),
  EthTransferList: () => import('../..\\components\\eth\\TransferList.vue' /* webpackChunkName: "components/eth-transfer-list" */).then(c => wrapFunctional(c.default || c)),
  EthTxTip: () => import('../..\\components\\eth\\TxTip.vue' /* webpackChunkName: "components/eth-tx-tip" */).then(c => wrapFunctional(c.default || c)),
  EthTxTokens: () => import('../..\\components\\eth\\TxTokens.vue' /* webpackChunkName: "components/eth-tx-tokens" */).then(c => wrapFunctional(c.default || c)),
  EthTxTransfer: () => import('../..\\components\\eth\\TxTransfer.vue' /* webpackChunkName: "components/eth-tx-transfer" */).then(c => wrapFunctional(c.default || c)),
  EthUncleList: () => import('../..\\components\\eth\\UncleList.vue' /* webpackChunkName: "components/eth-uncle-list" */).then(c => wrapFunctional(c.default || c)),
  EthValColor: () => import('../..\\components\\eth\\ValColor.vue' /* webpackChunkName: "components/eth-val-color" */).then(c => wrapFunctional(c.default || c)),
  LayoutMenu: () => import('../..\\components\\layout\\Menu.vue' /* webpackChunkName: "components/layout-menu" */).then(c => wrapFunctional(c.default || c)),
  LayoutNav: () => import('../..\\components\\layout\\Nav.vue' /* webpackChunkName: "components/layout-nav" */).then(c => wrapFunctional(c.default || c)),
  LayoutPageFooter: () => import('../..\\components\\layout\\PageFooter.vue' /* webpackChunkName: "components/layout-page-footer" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
