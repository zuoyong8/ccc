
const LRU = require('lru-cache');
const cookieparser = require('cookieparser');
function getCookieVuex(cookie) {
  let parsed = cookieparser.parse(cookie || '');
  parsed.vuex = parsed.vuex ? JSON.parse(parsed.vuex) : { app: '' };
  return parsed.vuex;
}

//页面缓存
export const cachePage = new LRU({
  max: 100, // 缓存队列长度 最大缓存数量
  maxAge: 1000 * 5 , // 缓存时间 单位：毫秒
});

export default function (req, res, next) {
  const url = req._parsedOriginalUrl;
  const pathname = url.pathname;
  // const parsed = getCookieVuex(req.headers.cookie); //获取cookie
  const version = cachePage.get('version');
  const indexPageArr = ['/zh-cn', '/zh-hk', '/zh-tw', '/en', '/de', '/ko', '/fr', '/ru', '/ja', '/th', '/vi', '/id', '/hi'];      //设置需要缓存的页面路径
  let isHavePage = indexPageArr.some(item => item === pathname);
  // //更新版本清缓存
  // if (!version || version !== process.env.npm_package_version) {
  //   cachePage.reset();
  //   cachePage.set('version', process.env.npm_package_version);
  // }
  // 在服务端才进行缓存
  if (isHavePage && !process.browser) {
    const existsHtml = cachePage.get(pathname);
    if (existsHtml) {
      //  如果没有Content-Type:text/html 的 header，gtmetrix网站无法做测评
      res.setHeader('Content-Type', ' text/html; charset=utf-8');
      return res.end(existsHtml.html, 'utf-8');
    } else {
      res.original_end = res.end;
      res.end = function (data) {
        if (res.statusCode === 200) {
          // 设置缓存
          cachePage.set(pathname, {
            html: data,
          });
        }
        res.original_end(data, 'utf-8');
      };
    }
  }
  // 清理缓存
  if (pathname === '/cleancache') {
    cachePage.reset();
    res.statusCode = 200;
  }
  next();
}