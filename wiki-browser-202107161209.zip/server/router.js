
const menus = [
  {
    meta: {
      requireAuth: true, //菜单权限
    },
    path: "/:lang/user",
    name: "lang-user"
  }
]

const iterator = (list) => {
  for (let item of list) {
    for (let m of menus) {
      if ((item.name === m.name) && (item.path === m.path)) {
        item.meta = m.meta;
        // item.meta.requireAuth = true;
      }
    }
    if (item.children && item.children.length > 0) {
      iterator(item.children);
    }
  }
  return list;
};

export default (routes, resolve) => {
  routes = iterator(routes);
};