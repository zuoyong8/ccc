import colors from 'vuetify/es5/util/colors'
import routes from './server/router.js';
import fs from 'fs'

const path = require('path');
// const LRU = require('lru-cache');
const FileManagerPlugin = require("filemanager-webpack-plugin"); //引入
let packageName = 'wiki-browser';

function resolve(dir) {
  return path.join(__dirname, dir)
}
const formatDate = (date, fmt) => {
  if (!date) {
    return
  }
  let mat = fmt || 'yyyy-MM-dd';
  const getDate = new Date(date)
  const o = {
    'M+': getDate.getMonth() + 1,
    'd+': getDate.getDate(),
    'h+': getDate.getHours(),
    'm+': getDate.getMinutes(),
    's+': getDate.getSeconds(),
    'q+': Math.floor((getDate.getMonth() + 3) / 3),
    'S': getDate.getMilliseconds()
  }
  if (/(y+)/.test(mat)) {
    mat = mat.replace(RegExp.$1, (getDate.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  for (const k in o) {
    if (new RegExp('(' + k + ')').test(mat)) {
      mat = mat.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
    }
  }
  return mat
}

packageName += '-' + formatDate(new Date(), 'yyyyMMddhhmm');

// const cert = {
//   key: fs.readFileSync(path.resolve(__dirname, 'assets/cert/5709254__wikibtc.com.key')),
//   cert: fs.readFileSync(path.resolve(__dirname, 'assets/cert/5709254__wikibtc.com.pem'))
// };

export default {
  target: 'server',
  // Global page headers: https://go.nuxtjs.dev/config-head
  head: {
    title: '区块天眼·链上数据 - 区块链数据信息查询、分析、追踪、链上监控',
    meta: [
      { charset: 'utf-8' },
      {'http-equiv': 'X-UA-Compatible', content: 'edge'},
      { name: 'renderer', content: 'webkit'},
      { name: 'keyword', content: '区块天眼·链上数据 - 区块链数据信息查询、分析、追踪、链上监控' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: '区块天眼·链上数据 - 区块链数据信息查询、分析、追踪、链上监控' }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ],
  },
  server: {
    // https: process.env.NODE_ENV === 'production' ? cert : null,
    port: process.env.NODE_ENV === 'production' ? 8888 : 9999,//端口
    host: '0.0.0.0' // default: localhost   
  },

  // Global CSS: https://go.nuxtjs.dev/config-css
  css: [
    { src: '~/assets/style/base.scss', lang: 'scss' },
    { src: '~/assets/style/media.scss', lang: 'scss' },
    { src: '~/assets/style/common.scss', lang: 'scss' }
  ],

  styleResources: {
    scss: '~/assets/style/vars/*.scss',
  },
  router: {              // customize nuxt.js router (vue-router).
    middleware: ['i18n'],  // middleware all pages of the application
    extendRoutes: routes
  },

  render: {
    resourceHints: false,
    // bundleRenderer: {
    //   cache: new LRU({
    //     max: 1000,           // 最大的缓存个数
    //     maxAge: 1000 * 60 * 30    // 缓存30分钟
    //   })
    // }
  },
  serverMiddleware: [
    '~/server/serverPageCache.js'
  ],

  // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
  plugins: [
    '@/plugins/svg-icon', //注册svg插件文件 
    '@/plugins/i18n',
    '@/plugins/axios',
    '@/plugins/echart',
    '@/plugins/mixin',
    { src: '@/plugins/babel-polyfill', ssr: true }, // 将es6转换为es5 兼容ie9
    { src: '~/plugins/eventBus' },
    { src: '~/plugins/directive' },
    { src: '~/plugins/serverCache' },
    // { src: '~/plugins/router' },
    { src: '~/plugins/baiduMap', ssr: false },
    { src: '~/plugins/tip', ssr: false },
    { src: '~/plugins/vue-messages', ssr: false },
    { src: '~/plugins/localStorage.js', ssr: false },
    { src: '~plugins/vue-infinite-scroll', ssr: false },
    { src: "~/plugins/swiper.js", ssr: false }
  ],

  // Auto import components: https://go.nuxtjs.dev/config-components
  components: true,

  // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
    ['@nuxtjs/vuetify', {
      theme: { disable: true },
    }]
  ],
  env: {
    baseURL: process.env.BASE_URL,
    NODE_ENV: process.env.NODE_ENV,
  },
  axios: {
    retry: {
      retries: 3,
      retryCondition: (err) => {
        if (err.message.indexOf('500')) {
          return true;
        } else {
          return false;
        }
      }
    }
  },

  // Modules: https://go.nuxtjs.dev/config-modules
  modules: [
    '@nuxtjs/axios',
    '@nuxtjs/style-resources',
  ],
  loading: {
    color: '#f06513',
    height: '3px'
  },

  // Vuetify module configuration: https://go.nuxtjs.dev/config-vuetify
  vuetify: {
    customVariables: ['~/assets/style/vuetify.scss'],
    breakpoint: {
      // mobile: false,
      // mobileBreakpoint: 0,
    },
    theme: {
      light: true,
      themes: {
        light: {
          primary: colors.blue.lighten2,
          accent: colors.grey.lighten3,
          secondary: colors.amber.lighten3,
          info: colors.teal.lighten1,
          warning: colors.amber.base,
          error: colors.deepOrange.accent4,
          success: colors.green.accent3,
          org: '#F06513',
        }
      }
    }
  },

  // Build Configuration: https://go.nuxtjs.dev/config-build
  build: {
    analyze: false,
    babel: {
      compact: false
    },
    productionSourceMap: false,
    productionGzip: true,
    productionGzipExtensions: ['js', 'css', 'svg'],
    extractCSS: {
      ignoreOrder: true
    },
    splitChunks: {
      layouts: true,
    },
    extend(config, ctx) {
      // 排除 nuxt 原配置的影响,Nuxt 默认有vue-loader,会处理svg,img等
      // 找到匹配.svg的规则,然后将存放svg文件的目录排除
      const svgRule = config.module.rules.find(rule => rule.test.test('.svg'))
      svgRule.exclude = [resolve('assets/icons/svg')]
      //添加loader规则
      config.module.rules.push({
        test: /\.svg$/, //匹配.svg
        include: [resolve('assets/icons/svg')], //将存放svg的目录加入到loader处理目录
        use: [{ loader: 'svg-sprite-loader', options: { symbolId: 'icon-[name]' } }]
      });

      // plugins插件是一个数组且webpack本身已经有一些配置，那么我们需要将其追加到数组中
      let fileM = new FileManagerPlugin({
        events: {
          onStart: [
            {
              delete: [
                {
                  source: `./*.zip`,
                  options: {
                    force: true,
                  },
                }
              ],
            }
          ],

          onEnd: [
            {
              mkdir: ['./zip', './zip/.nuxt/'],
            },
            {
              copy: [
                { source: `./.nuxt`, destination: `./zip/.nuxt/` },
                { source: `./static`, destination: `./zip/static/` },
                { source: `./nuxt.config.js`, destination: `./zip/nuxt.config.js` },
                { source: `./package.json`, destination: `./zip/package.json` },
                { source: `./server`, destination: `./zip/server/` },
              ],
            },
            {
              archive: [
                { source: `./zip`, destination: `./${packageName}.zip`, },
              ],
            },
            {
              delete: [{
                source: `./zip`,
                options: {
                  force: true,
                },
              }]
            }
          ]
        }
      })
      if (process.env.NODE_ENV === 'production' && ctx.isServer) {
        config.plugins.push(fileM)
      }

    },
  }
}
